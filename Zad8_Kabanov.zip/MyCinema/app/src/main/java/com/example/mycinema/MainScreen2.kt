package com.example.mycinema

import androidx.appcompat.app.AppCompatActivity

class MainScreen2: AppCompatActivity() {

}
